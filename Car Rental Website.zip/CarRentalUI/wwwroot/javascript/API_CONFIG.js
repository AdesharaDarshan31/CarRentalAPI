﻿// API base
const API_BASE_URL = "http://localhost:5139/api";

// UI static files root
const API_IMAGE_ROOT = "http://localhost:5256";  // UI PORT
